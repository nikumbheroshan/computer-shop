<?php include('server.php') ?>
<!-- <!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html> -->








<html>
<head>
<title>Registration </title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Acme&family=Chewy&family=Permanent+Marker&display=swap" rel="stylesheet">
   <style>
	    body{
		 margin: 0%;
  padding: 0%; 
  font-family: sans-serif;
  background-size: cover;
  background-color: rgb(19, 53, 104);
	   } 
      input[type="text"],
      input[type="number"],
      input[type="date"],
      input[type="password"],
      select {
         border: 1px solid rgb(4, 0, 12);
         border-radius: 5px;
         padding: 5px;
         margin: 5px;
      }
form {
         background-color: #f1f1f1;
         width: 40%;
         padding:20px;
		   font-family: 'Acme', sans-serif;
         border: 1px solid #3c7792;
      }
input[type="submit"] {
         border-radius: 5px;
         padding: 5px;
         margin: 5px;
         background-color: green;
         color: white;
         font-size: 14;
      }
input[type="submit"] {
         border-radius: 5px;
         padding: 5px;
         margin: 5px;
         background-color: red;
         color: white;
         font-size: 14;
      }
   </style>
    <script>
function input(e) {
         e.style.backgroundColor = "yellow";
      }
      function reset1(e) {
         e.style.backgroundColor = "white";
      }
      function fullName() {
         var f = document.getElementById("fname").value;
         var m = document.getElementById("mname").value;
         var l = document.getElementById("lname").value;
         document.getElementById("sname").value = f + " " + m + " " + l;
      }
      function checkEmail()
  {
   var email = document.getElementById('email').value
   var regex = /^([a-zA-Z0-9_\.]+)@([a-zA-Z0-9_\.]+)\.([a-zA-Z]{2,5})$/
   var res = regex.test(email)  

   var card_no = document.getElementById('card_no').value
   var re1 = /\d{4}\.\d{4}\.\d{4}/
   var re2 = /\d{4}\-\d{4}\-\d{4}/
  
  var res = re1.test(card_no) || re2.test(card_no)

  var phone = document.getElementById('phone').value
  var regex = /^\d{10}$/;
  var res = regex.test(phone)  

   if(!res) {
    alert('Please enter valid email id,adhar no. or phone no.')
   }
  }

  
   </script> 
</head>
<body>
   <center>
      <form  method="post" action="register.php">
	  <?php include('errors.php'); ?>
         <h1>Registration Form</h1>
         <table>
            <tr>
               <td>First Name</td>
               <td><input type="text" id="fname" placeholder="Enter first name" onclick="input(this)"
                     onblur="reset1(this)" oninput="fullName()" /></td>
            </tr>
            <tr>
               <td>Middle Name</td>
               <td><input type="text" id="mname" placeholder="Enter middle name" onclick="input(this)"
                     onblur="reset1(this)" oninput="fullName()" /></td>
            </tr>
            <tr>
               <td>Last Name</td>
               <td><input type="text" id="lname" placeholder="Enter last name" onclick="input(this)"
                     onblur="reset1(this)" oninput="fullName()" /></td>
            </tr>
            <tr>
               <td>Full Name</td>
               <td><input type="text" id="sname" name="fullname" value="<?php echo $fullname; ?>"/></td>
            </tr>
            <tr>
               <td>Date of Birth</td>
               <td>
               <input type="date" name="date" value="<?php echo $username; ?>">
               </td>
            </tr>
            
            
            <tr>
               <td>Gender</td>
               <td>
                  <input type="radio" name="gender" value="Male">Male</input>
                  &nbsp;&nbsp;&nbsp;&nbsp;
                  <input type="radio" name="gender" value="Female">Female</input>
               </td>
            </tr>
            
            
               <td>Email</td>
               <td>
                  <input type="text" name="email" id="email" value="<?php echo $email; ?>" />
               </td>
            </tr>
            
            <tr>
               <td>Phone</td>
               <td>
                  <input type="number" name="phone" id="phone" value="<?php echo $phone; ?>" />
               </td>
            </tr>
            
            <tr>
               <td>Username</td>
               <td><input type="text" id="sname" name="username" value="<?php echo $username; ?>"/></td>
            </tr>
            <tr>
               <td>Password</td>
               <td>
                  <input type="password" name="password_1"/>
               </td>
            </tr>
            <tr>
               <td>Comfirm Password</td>
               <td>
                  <input type="password" name="password_2"/>
               </td>
            </tr>
            <tr>
               <td></td>
               <td>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="register" name="reg_user" onclick="checkEmail()" />
                  <!-- <input type="submit" value="Sign in" url="login.php" /> -->
				  <tr>
			<td>Already a member? <a href="login.php">Sign in</a><td>
	       </tr>
  		
               </td>
            </tr>
			
         </table>
      </form>
   </center>
</body>
</html>