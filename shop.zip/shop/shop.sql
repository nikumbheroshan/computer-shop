-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2022 at 04:43 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `sp`
--

CREATE TABLE `sp` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `phone` bigint(10) NOT NULL,
  
  `date` date DEFAULT NULL,
  
  `gender` varchar(10) NOT NULL,
 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp`
--

INSERT INTO `sp` (`id`, `username`, `fullname`, `email`, `password`, `phone`, `date`, `gender`) VALUES
(54, 'megha patil', 'megha more', 'megha@gmail.com', 'fbade9e36a3f36d3d676c1b808451dd7', 8764512321, 436789878675, '2022-04-05', 'first,Boostdose', 'Female', '20', 'covidsheild', 'FYCO'),
(67, 'wq', 'janu manoj patil', 'janu@gmail.com', '0cc175b9c0f1b6a831c399e269772661', 45362823673, 6453736276246, '2022-04-12', 'Secound(2),BoostDose', 'Female', '20', 'Covidshild', 'SYCO'),
(68, 'janavi patil', 'janavi manoj patil', 'janavi@gmail.com', 'e1671797c52e15f763380b45e841ec32', 4555555578465, 453563333335, '2022-04-12', 'First(1),Secound(2)', 'Female', '23', 'Covaccine', 'FYCO'),
(69, 'x', 'xyz', 'xyz@gmail.com', '9dd4e461268c8034f5c8564e155c67a6', 3423254534, 234255555555, '2022-04-13', 'First(1),Secound(2)', 'Female', '23', 'Covidshild', 'FYCO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sp`
--
ALTER TABLE `sp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sp`
--
ALTER TABLE `sp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
