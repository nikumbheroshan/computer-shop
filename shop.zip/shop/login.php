<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">

   <!-- Favicons -->
   <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
	body{
  margin: 0%;
  padding: 0%;
  font-family: sans-serif;
  /* background-image: "covid.jpg"; */
  background-size: cover;
  background-color: rgb(8, 41, 112);
  
}
.box{
  width: 300px;
  padding: 30px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  background: rgba(0,0,0,0);
  text-align: center;
}
.box h1{
  color: white;
  text-transform: uppercase;
  font-weight: 700;

}
.box input[type="text"],.box input[type="password"]
{
  border:0;
  background:none;
  display:block;
  margin:20px auto;
  text-align:center;
  border: 3px solid #0367f0;
  padding: 14px 10px;
  width: 220px;
  outline: none;
  color: white;
  border-radius: 24px;
  transition: 0.25px;

}
.box input[type="text"]:focus,.box input[type="password"]:focus{
  width: 270px;
  border-color: #ffc400ec;

}
.box input[type="submit"]{
  border:0;
  background:none;
  display:block;
  margin:20px auto;
  text-align:center;
  border: 3px solid #ffc400ec;
  padding: 14px 10px;
  
  outline: none;
  color: white;
  border-radius: 24px;
  transition: 0.25px;
  cursor: pointer;
}
.box input[type="submit"]:hover{
  background: #ffc400ec;

}
.sign h4{
    border:0;
    background:none;
    display:block;
    margin:20px auto;
    text-align:center;
    border: 3px solid #ffc400ec;
    padding: 14px 10px;
    
    outline: none;
    color: white;
    border-radius: 24px;
    transition: 0.25px;
    cursor: pointer;
}
</style>
</head>

<!-- <body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="login.php">
  	
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html> -->
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <title>new login</title>
    <link rel="stylesheet" href="style2.css"> 
</head> -->
<body>
    <form class="box" action="login.php" method="post">
	<?php include('errors.php'); ?>
        <h1>
            Login
        </h1>
        <input type="text" name="username" placeholder="username" id="username">
        <input type="password" name="password" placeholder="password" id="password">
       
        <input type="submit" name="login_user" value="login" >
        
        <div class="sigh">
  		<h3>Not yet a member? <a href="register.php">Sign up</a></h3>
</div>
  	

    </form>
</body>
</html>